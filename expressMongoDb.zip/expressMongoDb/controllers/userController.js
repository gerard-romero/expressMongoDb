const userModel = require('../models/user');
const jwt =require('jsonwebtoken');
const bcrypt = require('bcrypt');

const createToken = (id) => jwt.sign({ id:id}, process.env.JWT_SECRET, {expiresIn: "1d"});

exports.authUser = async (req,res) => {
    try {
        const {email, password } = req.body;
        const user = await userModel.findOne({email});
        if(!user)throw new Error ('Wrong email or password');
        if(!await  bcrypt.compare(password,user.password))throw new Error ('Wrong email or password');
        const token = createToken(user.id);
        res.status(200).json ({success: true,token})
    }catch(error){
        res.status(500).json({ success:false,message :'Erreur serveur'});
    
    }};

exports.getUsers =async (req,res) => {
try {
    const users = await userModel.find();
    res.status(200).json({ success:true, data : users})

}catch(error){
    res.status(500).json({ success:false,message :'Erreur serveur'});

}};

exports.createUsers =   async (req,res) => {
    try {
        const { name, email, password } = req.body;
        const salt = await bcrypt.genSalt(10);
        const hashedPass = await bcrypt.hash(password,salt);

        await userModel.create({name, email,password: hashedPass});
        res.status(201).json({success: true});

        
    } catch (error) {
        console.error(error);
        
        res.status(500).json({ success:false,message :'Erreur serveur'}); 
    }
    
};

exports.updateUser = async (req,res) =>{
    try {
        const{id} = req.params;
        const { name, email, password } = req.body;
        await userModel.findByIdAndUpdate(id, {name, email, password});
        res.status(200).json({success: true});

        
    } catch (error) {
        res.status(500).json({ success:false,message :'Erreur serveur'});

        
    }
};

exports.deleteUser = async (req,res) =>{
    try {
        const{id} = req.params;
        const { name, email, password } = req.body;
        await userModel.findByIdAndDelete(id, {name, email, password});
        res.status(200).json({success: true});

        
    } catch (error) {
        res.status(500).json({ success:false,message :'Erreur serveur'});

        
    }
};