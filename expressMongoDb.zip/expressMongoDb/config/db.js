const mongoose =require('mongoose');

const connectDb = async () =>{
    try{
    
        await mongoose.connect(process.env.DB_URL);
        console.log('bd connectée');
        
    }catch(error){
        console.error('Erreur de connection à la bdd', error);
        
    }

};

module.exports = connectDb;
