# expressMongoDb

installation sur le terminal de :

npm init -y, express, mongoose, jsonwebtoken, nodemon, bcrypt.

Dans le package.json, on initie le start avec nodemon et le nom de l'application.

Création des variables.

PORT : 3000.
