const express = require('express');
const router = express.Router();
const {validate} = require('../middleware/jwt');

const { authUser,getUsers, createUsers, updateUser, deleteUser} = require ('../controllers/userController')


router.post('/',authUser);
router.get('/', getUsers);
router.post ('/register',createUsers);
router.put("/:id",validate, updateUser);
router.delete ('/:id',validate,deleteUser)

module.exports = router;